import React from 'react'
import { View,Text } from 'react-native'
export default function Box() {
  return (
   <View style={{ backgroundColor:'white' , width: 200, height:100 , borderWidth:2, borderRadius:2}}>
<Text>Hi</Text>
   </View>
  )
}
