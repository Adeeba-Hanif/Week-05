import React from 'react'
import SearchField from './SearchField'
import { View ,Text} from 'react-native'
import Box from './Box'
export default function Assignment1() {
  return (
   <>
   <SearchField></SearchField>
   <View>
    <Text>Lets find your doctor</Text>
   </View>
   <View>
<Box></Box>
   </View>
   </>
  )
}
