import {View, Text, Button} from 'react-native'
export default function ButtonLogic()
{
    return (
        <>
        <View>
        <Button title='Submit' color='red'></Button>
        </View>
        </>

    )
}